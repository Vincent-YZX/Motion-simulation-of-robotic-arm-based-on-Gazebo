#! /bin/bash
source ./devel/setup.bash

gnome-terminal -- bash -c "roscore;exec bash"

sleep 3

gnome-terminal -- bash -c "source ./devel/setup.bash ; rosrun turtlesim turtlesim_node ;exec bash"

sleep 3

gnome-terminal -- bash -c "source ./devel/setup.bash ; rosrun myturtle turtle_create.py ;exec bash"

sleep 3

gnome-terminal -- bash -c "source ./devel/setup.bash ; rosrun myturtle turtle_navigation.py ;exec bash"

sleep 3

gnome-terminal -- bash -c "source ./devel/setup.bash ; rosrun myturtle turtle_pose.py ;exec bash"

sleep 3

gnome-terminal -- bash -c "source ./devel/setup.bash ; rosrun myturtle turtle_color.py ;exec bash"

sleep 3

gnome-terminal -- bash -c "source ./devel/setup.bash ; rosrun myturtle turtle_chase.py ;exec bash"