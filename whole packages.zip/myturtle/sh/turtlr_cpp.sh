#! /bin/bash
source ./devel/setup.bash

gnome-terminal -- bash -c "roscore;exec bash"

sleep 3

gnome-terminal -- bash -c "source ./devel/setup.bash ; rosrun turtlesim turtlesim_node ;exec bash"

sleep 3

gnome-terminal -- bash -c "source ./devel/setup.bash ; rosrun myturtle gui_create ;exec bash"

sleep 3

gnome-terminal -- bash -c "source ./devel/setup.bash ; rosrun myturtle gui_navigation ;exec bash"

sleep 3

gnome-terminal -- bash -c "source ./devel/setup.bash ; rosrun myturtle gui_pose ;exec bash"

sleep 3

gnome-terminal -- bash -c "source ./devel/setup.bash ; rosrun myturtle gui_color ;exec bash"

sleep 3

gnome-terminal -- bash -c "source ./devel/setup.bash ; rosrun myturtle gui_chase  ;exec bash"