#!/usr/bin/env python3
import rospy
import math
from turtlesim.srv import Spawn, SpawnRequest
from turtlesim.msg import Pose
from geometry_msgs.msg import Twist

# 全局变量：存储两只海龟的位姿
group19_pose = None
groupx2_pose = None

# 订阅Group19位姿的回调函数
def group19_pose_callback(data):
    global group19_pose
    group19_pose = data

# 订阅GroupX_2位姿的回调函数
def groupx2_pose_callback(data):
    global groupx2_pose
    groupx2_pose = data

if __name__ == "__main__":
    # 1. 初始化 ROS 节点
    rospy.init_node("turtle_chase_integrated")
    
    # 2. 生成追赶海龟Group19_2
    try:
        spawn_client = rospy.ServiceProxy("/spawn", Spawn)
        spawn_client.wait_for_service()
        req = SpawnRequest()
        req.x = 8.0   
        req.y = 8.0
        req.theta = 0.0  # GroupX_2初始朝向（弧度）
        req.name = "Group19_2"
        response = spawn_client.call(req)
        rospy.loginfo("乌龟Group19_2创建成功！，叫:%s", response.name)
    except:
        rospy.loginfo("生成Group19_2服务调用失败")
        exit()  # 生成失败则退出
    
    # 3. 创建订阅者对象：分别订阅两只海龟的位姿
    sub_group19 = rospy.Subscriber("/Group19/pose", Pose, group19_pose_callback, queue_size=1000)
    sub_groupx2 = rospy.Subscriber("/Group19_2/pose", Pose, groupx2_pose_callback, queue_size=1000)
    
    # 4. 创建发布者对象：发布GroupX_2的运动控制指令
    cmd_vel_pub = rospy.Publisher("/Group19_2/cmd_vel", Twist, queue_size=1000)
    
    # 5. 循环频率与运动参数
    rate = rospy.Rate(10)
    twist_msg = Twist()
    speed_coefficient = 0.3   # 线速度 = 系数 × 距离
    angular_coefficient = 4.0 # 角速度比例系数（控制转向灵敏度）

    while not rospy.is_shutdown():
        if group19_pose is not None and groupx2_pose is not None:
            # 计算直线距离
            dx = group19_pose.x - groupx2_pose.x
            dy = group19_pose.y - groupx2_pose.y
            distance = math.sqrt(dx**2 + dy**2)
            
            # 计算目标朝向角度（弧度）
            target_angle = math.atan2(dy, dx)
            
            # 设置运动指令
            twist_msg.linear.x = speed_coefficient * distance
            twist_msg.angular.z = angular_coefficient * (target_angle - groupx2_pose.theta)
            
            # 发布运动指令
            cmd_vel_pub.publish(twist_msg)
            
            # 实时打印信息
            rospy.loginfo("直线距离: %.2f | Group19_2朝向角度: %.2f°", 
                         distance, groupx2_pose.theta * 180/math.pi)
        rate.sleep()