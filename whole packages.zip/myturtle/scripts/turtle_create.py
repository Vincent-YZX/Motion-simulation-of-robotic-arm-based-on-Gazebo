#! /usr/bin/env python3
import rospy 
from turtlesim.srv import Spawn,SpawnRequest,SpawnResponse

if __name__ == "__main__":
    # 初始化 ros 节点
    rospy.init_node("set_turtle_p")
    # 创建 service 客户端
    client = rospy.ServiceProxy("/spawn",Spawn)
    # 等待服务启动
    client.wait_for_service()
    # 发送请求
    req = SpawnRequest()
    req.x = 5
    req.y = 5
    req.theta = -1.57
    req.name = "Group19"
    try:
        response = client.call(req)
        # 处理响应
        rospy.loginfo("乌龟创建成功!，叫:%s",response.name)
    except expression as identifier:
        rospy.loginfo("服务调用失败")