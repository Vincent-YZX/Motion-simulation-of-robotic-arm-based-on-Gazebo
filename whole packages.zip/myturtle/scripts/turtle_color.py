#!/usr/bin/env python3
import rospy
import random
from std_srvs.srv import Empty  # /clear服务与/reset同类型

def bg_color_callback(event):
    """定时器回调：更新背景色参数并触发重绘"""
    # 生成0-255随机RGB值
    r = random.randint(0, 255)
    g = random.randint(0, 255)
    b = random.randint(0, 255)

    # 更新参数服务器中的背景色
    rospy.set_param("/turtlesim/background_r", r)
    rospy.set_param("/turtlesim/background_g", g)
    rospy.set_param("/turtlesim/background_b", b)

    # 调用/clear服务（清除轨迹+重绘窗口，加载新背景色，保留乌龟）
    try:
        rospy.wait_for_service("/clear", timeout=5.0)
        clear_service = rospy.ServiceProxy("/clear", Empty)
        clear_service()  # 触发重绘，新背景色生效
        rospy.loginfo("背景色更新：R=%d, G=%d, B=%d", r, g, b)
    except rospy.ROSException as e:
        rospy.logerr("调用clear服务失败：%s", str(e))

if __name__ == "__main__":
    rospy.init_node("random_bgcolor_node", anonymous=True)
    # 1秒周期定时器
    rospy.Timer(rospy.Duration(1.0), bg_color_callback)
    rospy.spin()