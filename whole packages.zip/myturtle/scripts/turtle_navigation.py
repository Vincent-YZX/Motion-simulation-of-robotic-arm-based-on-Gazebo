#! /usr/bin/env python3
import rospy
from geometry_msgs.msg import Twist

if __name__ == "__main__":
    # 初始化 ROS 节点
    rospy.init_node("control_circle_p")
    # 创建发布者对象
    pub = rospy.Publisher("/Group19/cmd_vel",Twist,queue_size=1000)
    # 循环发布运动控制消息
    rate = rospy.Rate(10)
    msg = Twist()
    msg.linear.x = 1.0
    msg.linear.y = 0.0
    msg.linear.z = 0.0
    msg.angular.x = 0.0
    msg.angular.y = 0.0
    msg.angular.z = -0.5

    while not rospy.is_shutdown():
        pub.publish(msg)
        rate.sleep()