#include <ros/ros.h>
#include <std_srvs/Empty.h>
#include <cstdlib>
#include <ctime>

// 定时器回调函数：随机设置背景色并触发重绘
void bgColorCallback(const ros::TimerEvent& event) {
    // 生成 0-255 之间的随机 RGB 值
    int r = rand() % 256;
    int g = rand() % 256;
    int b = rand() % 256;

    // 更新参数服务器中的背景色参数
    ros::param::set("/turtlesim/background_r", r);
    ros::param::set("/turtlesim/background_g", g);
    ros::param::set("/turtlesim/background_b", b);

    // 调用 /clear 服务（触发窗口重绘，加载新背景色，保留乌龟）
    ros::ServiceClient clearClient = ros::service::createClient<std_srvs::Empty>("/clear");
    std_srvs::Empty srv;

    if (clearClient.waitForExistence(ros::Duration(5.0))) {
        if (clearClient.call(srv)) {
            ROS_INFO("背景色更新：R=%d, G=%d, B=%d", r, g, b);
        } else {
            ROS_ERROR("调用 /clear 服务失败");
        }
    } else {
        ROS_ERROR("/clear 服务不可用（超时 5 秒）");
    }
}

int main(int argc, char** argv) {
    setlocale(LC_ALL,"");
    // 初始化 ROS 节点
    ros::init(argc, argv, "random_bgcolor_cpp_node");
    ros::NodeHandle nh;

    // 初始化随机数种子（确保每次启动随机序列不同）
    srand(time(NULL));

    // 创建定时器：每隔 1 秒执行一次回调
    ros::Timer timer = nh.createTimer(ros::Duration(1.0), bgColorCallback);

    // 循环等待回调执行
    ros::spin();

    return 0;
}