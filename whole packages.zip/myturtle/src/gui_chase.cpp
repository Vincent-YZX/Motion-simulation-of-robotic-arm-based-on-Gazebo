#include <ros/ros.h>
#include <turtlesim/Spawn.h>
#include <turtlesim/Pose.h>
#include <geometry_msgs/Twist.h>
#include <cmath>

// 全局变量：存储两只海龟的位姿
turtlesim::Pose group19_pose;
turtlesim::Pose group19_2_pose;
// 标记位姿是否已初始化（避免空指针访问）
bool group19_pose_init = false;
bool group19_2_pose_init = false;

// 订阅Group19位姿的回调函数
void group19PoseCallback(const turtlesim::Pose::ConstPtr& msg) {
    group19_pose = *msg;
    group19_pose_init = true;
}

// 订阅Group19_2位姿的回调函数
void group19_2PoseCallback(const turtlesim::Pose::ConstPtr& msg) {
    group19_2_pose = *msg;
    group19_2_pose_init = true;
}

int main(int argc, char**argv) {
    setlocale(LC_ALL,"");
    // 初始化ROS节点
    ros::init(argc, argv, "turtle_chase_integrated");
    ros::NodeHandle nh;

    // 生成追赶海龟Group19_2（对应Python的spawn逻辑）
    ros::ServiceClient spawn_client = nh.serviceClient<turtlesim::Spawn>("/spawn");
    // 等待/spawn服务可用
    if (!spawn_client.waitForExistence(ros::Duration(5.0))) {
        ROS_ERROR("生成Group19_2失败：/spawn服务未启动");
        return 1;
    }
    // 构造spawn请求
    turtlesim::Spawn spawn_req;
    spawn_req.request.x = 8.0;
    spawn_req.request.y = 8.0;
    spawn_req.request.theta = 0.0;
    spawn_req.request.name = "Group19_2";
    // 调用服务
    if (!spawn_client.call(spawn_req)) {
        ROS_ERROR("生成Group19_2失败：服务调用失败");
        return 1;
    }
    ROS_INFO("乌龟Group19_2创建成功！，叫: %s", spawn_req.response.name.c_str());

    // 创建订阅者（对应Python的Subscriber）
    ros::Subscriber sub_group19 = nh.subscribe(
        "/Group19/pose", 1000, group19PoseCallback
    );
    ros::Subscriber sub_group19_2 = nh.subscribe(
        "/Group19_2/pose", 1000, group19_2PoseCallback
    );

    // 创建发布者
    ros::Publisher cmd_vel_pub = nh.advertise<geometry_msgs::Twist>(
        "/Group19_2/cmd_vel", 1000
    );

    // 循环频率与运动参数
    ros::Rate rate(10);  
    geometry_msgs::Twist twist_msg;
    const double speed_coefficient = 0.3;    // 线速度系数
    const double angular_coefficient = 3.0;  // 角速度系数

  
    while (ros::ok()) {
        // 确保两只海龟的位姿都已初始化
        if (group19_pose_init && group19_2_pose_init) {
            // 计算直线距离
            double dx = group19_pose.x - group19_2_pose.x;
            double dy = group19_pose.y - group19_2_pose.y;
            double distance = sqrt(dx*dx + dy*dy);

            // 计算目标朝向角度
            double target_angle = atan2(dy, dx);

            // 设置运动指令
            twist_msg.linear.x = speed_coefficient * distance;  // 线速度与距离成正比
            twist_msg.angular.z = angular_coefficient * (target_angle - group19_2_pose.theta);  // 角速度控制转向

            // 发布速度指令
            cmd_vel_pub.publish(twist_msg);


            ROS_INFO(
                "直线距离: %.2f | Group19_2朝向角度: %.2f°",
                distance,
                group19_2_pose.theta * 180.0 / M_PI  // 弧度转角度
            );
        }

        ros::spinOnce();
        rate.sleep();
    }

    return 0;
}