#include "ros/ros.h"
#include "turtlesim/Spawn.h"

int main(int argc, char *argv[])
{
    setlocale(LC_ALL,"");
    // 初始化 ros 节点
    ros::init(argc,argv,"set_turtle");
    // 创建 ros 句柄
    ros::NodeHandle nh;
    // 创建 service 客户端
    ros::ServiceClient client = nh.serviceClient<turtlesim::Spawn>("/spawn");
    // 等待服务启动
    // client.waitForExistence();
    ros::service::waitForService("/spawn");
    // 发送请求
    turtlesim::Spawn spawn;
    spawn.request.x = 5;
    spawn.request.y = 5;
    spawn.request.theta = 1.57;
    spawn.request.name = "Group19";
    bool flag = client.call(spawn);
    // 处理响应结果
    if (flag)
    {
        ROS_INFO("新的乌龟生成,名字:%s",spawn.response.name.c_str());
    } else {
        ROS_INFO("乌龟生成失败！！！");
    }


    return 0;
}